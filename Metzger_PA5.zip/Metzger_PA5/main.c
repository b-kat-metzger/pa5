/*Programmer: Ben Metzger
Date: 10/17/23
Class: Cpts 121 Lab section 15
Description: Text based game of yahtzee


yuh*/
#include "header.h"

int main(){

	srand((unsigned int)time(NULL));
	int count = 1;
	
	do {
		do {
			printf("\n============================================\n1)Print Rules\n2)Play Game\n3)Exit Game\n============================================\n");
			scanf("%d", &count);
		} while (count < 1 || count > 3);
		switch (count) {
		case 1: print_game_rules();
			break;
		case 2:system("cls");
			play_game();
			break;
		case 3: printf("Exiting game... ");
			break;
		default:printf("");
			break;
		}
	} while (count != 3);

	return 0;
}