
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/*Function play_game
Date created: 10/21/23
Date modified: 10/21/23
Description: Plays a game of text based yahtzee between two people. Implements all other functions. Only called once per game, and will complete the game
Inputs / Outputs: void
Precondition: Option 2 was selected in main
Postcondition: none*/
void play_game();


/*Function print_game_rules
Date created: 10/18/23
Date modified: 10/18/23
Description: Prints out the rules of yahtzee. Called in main()
Inputs / Outputs: void
Precondition: none
Postcondition: none*/
void print_game_rules();

/*Function roll_dice
Date created: 10/18/23
Date modified: 10/18/23
Description: Will roll dice based on values of reroll_dice_arr[]. If value of reroll_dice_arr[i] == 1, reroll/roll the dice and reassign the value.
If value of reroll_dice_arr[i] == 0, leave alone. Returns values back to dice_arr[] in values of dice face.
Input: reroll_dice_arr[], initialized as either 0 or 1.
Output: Face values to dice_arr[]
Precondition: reroll_dice_arr[] is initiallized with either 0 or 1 to determine what gets rerolled
Postcondtiion: dice_arr[] will be populated with new dice values. */
void roll_dice(int reroll_dice_arr[], int dice_arr[]);

/*Function calc_score
Date created: 10/18/23
Date modified: 10/23/23
Description: Based on the user selection, function will calculate the score for the player for this given turn. Checks user selection with a valid combo.
If selection is between 1 and 6, will multiply face value by the amount of that value, taken from frequency. If selection is between 7-12, will check if the
selection is valid by using valid_combos[]. If result of valid_combos[] is 1 for the given selection, the then the program will according award points.
If selection is 13, returns the sum of the dice.
Input: dice_arr[],  int selection, frequency[], valid_combos[]
Output: Score as an integer
Precondition: 1 <= selection <= 13 and dice_arr[] is initiallized with face values between 1-6
Postcondtition: Score will be added to player scorecard for the corresponding selection value*/
int calc_score(int dice_arr[], int selection, int frequency[], int valid_combos[]);

/*Function determine_frequency
Date created: 10/18/23
Date modified: 10/18/23
Description: Loops through dice face values and tallies up the values. Updates frequency to match
Input: dice_arr[] and int frequency[]
Precondtion: dice_arr[] is properly defined with face values, frequency[] can be empty since it will be updated
Postcondition: frequency[] will be properly updated */
void determine_frequency(int dice_arr[], int frequency[]);

/*Function find_combos
Date created: 10/18/23
Date modified: 10/18/23
Description: Searches through frequency to determine if the player can earn points for lower section combinations. Updates valid_combos[]
Input: frequency[], valid_combos[]
Output: none, but updates valid_combos[]
Precondition: frequency[] is properly initialized
Postcondition: valid_combos[] will be properly updated*/
void find_combos(int frequency[], int valid_combos[]);

/*Function calc_lower
Date created: 10/20/23
Date modified: 10/23/23
Description: Loops through lower section of the score card and finds the sum. If the sum is >=63. Will return 1 (true) otherwise, false (0)
Input: Playcard lower section and current player
Output: int 1 for true or int 0 for false
Precondition: Every element in the lower section has been played (could still be zero)
Postcondition: calc_lower is called in main to determine if the player's score will be
*/
int calc_lower(int scorecard[2][14], int player);

/*Function clear_array
Date created: 10/20/23
Date modified: 10/20/23
Description: Sets all values of an array to 0
Input: array to be modified, int size of array
Output: none
Precondition: array is initialized, size matches the size of the array
Postcondition: none*/
void clear_array(int arr[], int size);

/*Function init_rerolls
Date created: 10/21/23
Date modified: 10/21/23
Description: Gets inputs from the user to determine which dice to reroll.
Input: array reroll_arr to rewrite the array and dice_arr[] to access the dice
Output: none
Precondition: 2nd or 3rd roll of player's turn
Postcondition: reroll_arr will be used in roll_dice
*/
void init_rerolls(int reroll_arr[], int dice_arr[]);

/*Function print_dice
Date created: 10/21/23
Date modified: 10/21/23
Description: Prints dice array on one line
Input: integer dice_arr[]
Output: void
Precondtiion: array initialized
Postcondition: none*/
void print_dice(int dice_arr[]);

/*Function sum_face
Date created: 10/23/23
Date modified: 10/23/23
Description: Calculates the sum of the face values of dice_arr[]
Input: dice_arr[]
Output: Integer for the sum
Precondition: dice_arr[] is properly initialized
Postcondition: To be used in score calculations*/
int sum_face(int dice_arr[]);

/*Function suggest_upper
Date created: 10/23/23
Date modified: 10/24/23
Description: Uses valid combinations to tell the user which valid upper scorecard selecitons would work for them. 
Input: canPlay[][] and valid_combos[]
Output: none
Precondition: Player is done rolling dice
Postcondition: Player will make their selection after given a suggestion*/
void suggest_upper(int canPlay[][14], int valid_combos[], int player, int dice_arr[]);

/*Function suggest_lower
Date created: 10/23/23
Date modified: 10/24/23
Description: Determines if any lower scorecard selctions can be used that would net any points
Input: canPlay[][], frequency[], int player, dice_arr[]
Output: none
Precondition: Player is done rolling dice
Postcondition: Player will make their selection after given a suggestion*/
void suggest_lower(int canPlay[][14], int frequency[], int player, int dice_arr[]);