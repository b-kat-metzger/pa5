#include "header.h"

/*Function play_game
Date created: 10/21/23
Date modified: 10/21/23
Description: Plays a game of text based yahtzee between two people. Implements all other functions. Only called once per game, and will complete the game
Inputs / Outputs: void
Precondition: Option 2 was selected in main
Postcondition: none*/
void play_game() {
	int dice_arr[] = { 0, 0, 0, 0, 0, 0 };
	
	int frequency[] = { 0,0,0,0,0,0,0 };
	//0 =Three of a kind, 1 = Four of a kind, 2 = Full House, 3 = Small Straight, 4 = Large Straight, 5 = YAHTZEE
	int valid_combos[] = { 0,0,0,0,0,0 };
	/*Index 0 is the total score of the scorecard, 1-6 is Ones-Sixes
	* 7 = Three of a kind, 8 = Four of a kind, 9 = Full House, 10 = Small Straight, 11 = Large Straight, 12 = YAHTZEE, 13 = Chance
	*
	*/
	//
	int scorecard[2][14] = { { 0,0,0,0,0,0,0,0,0,0,0,0,0,0 }, { 0,0,0,0,0,0,0,0,0,0,0,0,0,0 } };
	int canPlay[2][14] = { { 0,1,1,1,1,1,1,1,1,1,1,1,1,1 }, { 0,1,1,1,1,1,1,1,1,1,1,1,1,1 } };
	int turn = 1, current_player = 1, score = 0, selection = 1;
	int totalScore[] = { 0,0 };
	char doReroll = '\0';

	while (turn < 14) {
		for (int p = 1; p < 3; p++) {
			score = 0;
			current_player = p;
			int reroll_arr[] = { 0, 1, 1, 1, 1, 1 };
			//Roll 1
			system("cls");
			printf("\n=====================================================================\nCurrent turn: %d.  Player %d \n", turn, p);
			printf("Roll #1: \n");
			roll_dice(reroll_arr, dice_arr);
			print_dice(dice_arr);
			clear_array(frequency, 7);
			determine_frequency(dice_arr, frequency);
			printf("\nWould you like to reroll any of your dice? ('y' for yes) \n");
			scanf(" %c", &doReroll);
			if (doReroll == 'y') {
				init_rerolls(reroll_arr, dice_arr);
				roll_dice(reroll_arr, dice_arr);
				//Roll 2
				printf("Roll #2: \n");
				print_dice(dice_arr);
				clear_array(frequency, 7);
				determine_frequency(dice_arr, frequency);
				doReroll = '\0';
				printf("\nWould you like to reroll any of your dice? ('y' for yes) \n");
				scanf(" %c", &doReroll);
				if (doReroll == 'y') {
					init_rerolls(reroll_arr, dice_arr);
					roll_dice(reroll_arr, dice_arr);
					//Roll 3
					printf("Roll #3: \n");
					print_dice(dice_arr);
					clear_array(frequency, 7);
					determine_frequency(dice_arr, frequency);

				}
			}
			system("cls");
			find_combos(frequency, valid_combos);
			suggest_lower(canPlay, frequency, current_player - 1, dice_arr);
			suggest_upper(canPlay, valid_combos, current_player - 1, dice_arr);
			printf("Press any key to continue. ");
			getch();
			printf("\n\n\n"
				"	1-6) Ones, Twos, Threes, Fours, Fives, Sixes -- Number of corresponding value. \n	Score is the total of the value only.\n\n"
				" \n"
				"	7) Three of a kind -- Score is the total of all 5 dice\n"
				"	8) Four of a kind -- Score is the total of all 5 dice\n"
				"	9) Full House -- Three of a kind and a pair. Score is 25 points\n"
				"	10) Small straight -- Four values in order (Ex: 1,2,3,4). Score is 30 points\n"
				"	11) Large straight -- Five values in order (Ex. 2,3,4,5,6). Score is 40 points\n"
				"	12) YAHTZEE -- FIVE OF A KIND. SCORE IS 50 POINTS. IF YOU GET MULTIPLE YAHTZEES IN A GAME, \n	YOU MAY EARN AN ADDITIONAL 100 POINTS PER EXTRA YAHTZEE!\n"
				"	13) Chance -- This box will always award points. Score is the value of all dice. Think of as a catch-all. \n\n");
			do {
				printf("Make your selection for this round: \n");
				scanf("%d", &selection);
				printf("\n");
			} while (selection < 1 || selection > 13 || (canPlay[current_player - 1][selection] == 0));
			score = calc_score(dice_arr, selection, frequency, valid_combos);
			scorecard[current_player - 1][selection] = score;
			canPlay[current_player - 1][selection] = 0;
			printf("Score of %d has been stored in your scorecard. \n", score);
			clear_array(valid_combos, 5);
			printf("Press any button to swap players: ");
			getch();

		}
		
		turn++;
	}
	system("cls");
	printf("===========================================================\n\nThe game has now concluded! \n");
	for (int p = 0; p < 2; p++) {
		if (calc_lower(scorecard, p) == 1) {
			totalScore[p] += 35;
		}
		for (int i = 1; i < 14; i++) {
			totalScore[p] += scorecard[p][i];
		}
	}
	printf("Player 1 had a total of %d points! Player 2 had a total of %d points!\n", totalScore[0], totalScore[1]);
	if (totalScore[0] > totalScore[1]) {
		printf("Player 1 wins!\n");
	}
	else if(totalScore[1] > totalScore[0]) {
		printf("Player 2 wins!\n");
	}
	else {
		printf("A tie!? This is awkward...\n");
	}
	

}

/*Function print_game_rules
Date created: 10/18/23
Date modified: 10/18/23
Description: Prints out the rules of yahtzee. Called in main()
Inputs / Outputs: void
Precondition: none
Postcondition: none*/
void print_game_rules(void) {
	printf("-----------------------------------------------------------------------------------------------------------------\n"
		"The goal of the game is to get the highest score possible.Every player will have a scorecard.\n"
	"Players will roll three times per turn. On the first turn, players roll five dice. On the second and third turn, players may choose any amount of dice to reroll.\n"
		"After three rolls, the player will choose a combination from one of the following possible combinations: \n\n"

		"Upper Section: \n"
		"	1-6) Ones, Twos, Threes, Fours, Fives, Sixes -- Number of corresponding value. \n	Score is the total of the value only.\n\n"
		"Lower Section: \n"
		"	7) Three of a kind -- Score is the total of all 5 dice\n"
		"	8) Four of a kind -- Score is the total of all 5 dice\n"
		"	9) Full House -- Three of a kind and a pair. Score is 25 points\n"
		"	10) Small straight -- Four values in order (Ex: 1,2,3,4). Score is 30 points\n"
		"	11) Large straight -- Five values in order (Ex. 2,3,4,5,6). Score is 40 points\n"
		"	12) YAHTZEE -- FIVE OF A KIND. SCORE IS 50 POINTS. IF YOU GET MULTIPLE YAHTZEES IN A GAME, \n	YOU MAY EARN AN ADDITIONAL 100 POINTS PER EXTRA YAHTZEE!\n"
		"	13) Chance -- This box will always award points. Score is the value of all dice. Think of as a catch-all. \n"


		"You may only use one combination (excluding YAHTZEE) per game. Once that combintation is used up, you may not choose it again. \n"
		"Your goal for the upper section (Face values 1-6) is to get at least 63 points. Doing so will award the player an additional 35 bonus points. \n"
		"There may be instances when you are forced to pick a combination that will award zero points, in this case the combination will still be used up.\n"
		"The game ends when all combinations are claimed. The player with the most points wins. Good luck and have fun!\n"
		"-----------------------------------------------------------------------------------------------------------------------\n");
	
}

/*Function roll_dice
Date created: 10/18/23
Date modified: 10/18/23
Description: Will roll dice based on values of reroll_dice_arr[]. If value of reroll_dice_arr[i] == 1, reroll/roll the dice and reassign the value. 
If value of reroll_dice_arr[i] == 0, leave alone. Returns values back to dice_arr[] in values of dice face.
Input: reroll_dice_arr[], initialized as either 0 or 1. 
Output: Face values to dice_arr[]
Precondition: reroll_dice_arr[] is initiallized with either 0 or 1 to determine what gets rerolled
Postcondtiion: dice_arr[] will be populated with new dice values. */
void roll_dice(int reroll_dice_arr[], int dice_arr[]) {
	printf("\nPress any key to roll the dice: \n");
	getch();
	for (int i = 1; i < 7; i++) {
		if (reroll_dice_arr[i] == 1) {
			dice_arr[i] = (rand() % 6 + 1);
		}
	}
}

/*Function calc_score
Date created: 10/18/23
Date modified: 10/23/23
Description: Based on the user selection, function will calculate the score for the player for this given turn. Checks user selection with a valid combo.
If selection is between 1 and 6, will multiply face value by the amount of that value, taken from frequency. If selection is between 7-12, will check if the
selection is valid by using valid_combos[]. If result of valid_combos[] is 1 for the given selection, the then the program will according award points.
If selection is 13, returns the sum of the dice. 
Input: dice_arr[],  int selection, frequency[], valid_combos[]
Output: Score as an integer
Precondition: 1 <= selection <= 13 and dice_arr[] is initiallized with face values between 1-6
Postcondtition: Score will be added to player scorecard for the corresponding selection value*/
int calc_score(int dice_arr[], int selection, int frequency[], int valid_combos[]) {
	int score = 0;
	if (selection >= 1 && selection <= 6) {
		score = (selection * frequency[selection]);
	}
	if (selection >= 7 && selection <= 12) {
		switch (selection) {
		case 7: if (valid_combos[0] == 1) 
			score = sum_face(dice_arr);
			  else 
			score = 0;		
			  break;
		case 8:if (valid_combos[1] == 1) 
			score = sum_face(dice_arr);
			  else 
			score = 0;
			  break;
		case 9:if (valid_combos[2] == 1)
			score = 25;
			  else
			score = 0;
			break;
		case 10:if (valid_combos[3] == 1)
			score = 30;
			   else
			score = 0;
			break;
		case 11:if (valid_combos[4] == 1)
			score = 40;
			   else
			score = 0;
			break;
		case 12:if (valid_combos[5] == 1)
			score = 50;
			   else
			score = 0;
			break;
		}
		
	}
	if (selection == 13)
		score = sum_face(dice_arr);
	return score;
}

/*Function determine_frequency
Date created: 10/18/23
Date modified: 10/18/23
Description: Loops through dice face values and tallies up the values. Updates frequency to match
Input: dice_arr[] and int frequency[]
Precondtion: dice_arr[] is properly defined with face values, frequency[] can be empty since it will be updated
Postcondition: frequency[] will be properly updated */
void determine_frequency(int dice_arr[], int frequency[]) {
	for (int i = 1; i < 7; i++) {
		switch (dice_arr[i]) {
		case 1:
			frequency[1]+=1;
			break;
		case 2:
			frequency[2]+=1;
			break;
		case 3:
			frequency[3]+=1;
			break;
		case 4:
			frequency[4]+=1;
			break;
		case 5:
			frequency[5]+=1;
			break;
		case 6:
			frequency[6]+=1;
			break;
		default:
			break;
		}
	}
}

/*Function find_combos
Date created: 10/18/23
Date modified: 10/20/23
Description: Searches through frequency to determine if the player can earn points for lower section combinations. Updates valid_combos[]
Input: frequency[], valid_combos[]
Output: none, but updates valid_combos[]
Precondition: frequency[] is properly initialized
Postcondition: valid_combos[] will be properly updated*/
void find_combos(int frequency[], int valid_combos[]) {
	//Finding three of a kind, four of a kind, and yahtzee
	for (int i = 1; i < 7; i++) {
		if (frequency[i] >= 3)
			valid_combos[0] = 1;
		if (frequency[i] >= 4)
			valid_combos[1] = 1;
		if (frequency[i] == 5)
			valid_combos[5] = 1;
	}
	//Finding full house
	for (int i = 1; i < 7; i++) {
		if (frequency[i] > 2) {
			for (int j = 1; j < 7; j++) {
				if ((frequency[j] > 1) && (i != j)) {
					valid_combos[2] = 1;
				}
			}
		}
	}
	//Finding small and large straights
	int straight_combo = 0;
	for (int i = 1; i < 7; i++) {
		
		if (straight_combo == 4) {
			valid_combos[3] = 1;
		}
	
		if (frequency[i] > 0) {
			straight_combo++;	
		}
		
		else {
			straight_combo = 0;
		}
		if (straight_combo == 5) {
			valid_combos[4] = 1;

		}
	}
}

/*Function calc_lower
Date created: 10/20/23
Date modified: 10/20/23
Description: Loops through lower section of the score card and finds the sum. If the sum is >=63. Will return 1 (true) otherwise, false (0)
Input: Playcard lower section and current player
Output: int 1 for true or int 0 for false
Precondition: Every element in the lower section has been played (could still be zero)
Postcondition: calc_lower is called in main to determine if the player's score will be 
*/
int calc_lower(int scorecard[2][14], int player) {
	int sum = 0;
	for (int i = 1; i < 7; i++) {
		sum += scorecard[player][i];
	}
	if (sum >= 63) {
		return 1;
	}
	else {
		return 0;
	}
}

/*Function clear_array
Date created: 10/20/23
Date modified: 10/20/23
Description: Sets all values of an array to 0
Input: array to be modified, int size of array
Output: none
Precondition: array is initialized, size matches the size of the array
Postcondition: none*/
void clear_array(int arr[], int size) {
	for (int i = 0; i < size; i++) {
		arr[i] = 0;
	}
}

/*Function init_rerolls
Date created: 10/21/23
Date modified: 10/21/23
Description: Gets inputs from the user to determine which dice to reroll.
Input: array reroll_arr to rewrite the array and dice_arr to access the dice
Output: none
Precondition: 2nd or 3rd roll of player's turn
Postcondition: reroll_arr will be used in roll_dice
*/
void init_rerolls(int reroll_arr[], int dice_arr[]) {
	int selection = 0, dice_selection = 0;
	clear_array(reroll_arr, 6);
	do {
		printf("How many of your dice would you like to reroll? (Enter 0 if you'd like to keep your selection): \n");
		scanf("%d", &selection);
	} while (selection < 0 || selection > 5);
	if (selection != 0) {
		for (int i = 0; i < selection; i++) {
			print_dice(dice_arr);
			do {
				printf("Select which dice you would like to reroll (1-5): \n");
				scanf("%d", &dice_selection);
			} while (dice_selection > 5 || dice_selection < 1);
			reroll_arr[dice_selection] = 1;
		}
	}

}

/*Function print_dice
Date created: 10/21/23
Date modified: 10/21/23
Description: Prints array on one line
Input: integer dice_arr[]
Output: void
Precondtiion: array initialized
Postcondition: none*/
void print_dice(int dice_arr[]) {
	printf("\n");
	for (int i = 1; i < 6; i++) {
		printf("Dice %d: %d | ", i, dice_arr[i]);
	}
	printf("\n");
}

/*Function sum_face
Date created: 10/23/23
Date modified: 10/23/23
Description: Calculates the sum of the face values of dice_arr[]
Input: dice_arr[]
Output: Integer for the sum
Precondition: dice_arr[] is properly initialized
Postcondition: To be used in score calculations*/
int sum_face(int dice_arr[]) {
	int sum = 0;
	for (int i = 1; i < 6; i++) {
		sum += dice_arr[i];
	}
	return sum;
}

/*Function suggest_upper
Date created: 10/23/23
Date modified: 10/23/23
Description: Uses valid combinations to tell the user which valid upper scorecard selecitons would work for them.
Input: canPlay[][] and valid_combos[]
Output: none
Precondition: Player is done rolling dice
Postcondition: Player will make their seleciton after given a suggestion*/
void suggest_upper(int canPlay[][14], int valid_combos[], int player, int dice_arr[]) {
	printf("Here are some suggested combinations (and their scores) that you could play: \n");
	for (int i = 0; i < 6; i++) {
		if ((valid_combos[i] == 1) && (canPlay[player][i + 7])==1) {
			switch (i) {
			case 0: printf(" Three of a kind - %d\n", sum_face(dice_arr));
				break;
			case 1:printf(" Four of a kind - %d\n", sum_face(dice_arr));
				break;
			case 2:printf(" Full House - 25\n");
				break;
			case 3:printf(" Small Straight - 30\n");
				break;
			case 4: printf(" Large Straight - 40\n");
				break;
			}
		}
	}
	if (valid_combos[5] == 1) {
		printf(" YAHTZEE! - 50 **Can use as many times as you want \n");
	}
	if (canPlay[player][13] == 1) {
		printf(" Chance - %d\n", sum_face(dice_arr));
	}
}

/*Function suggest_lower
Date created: 10/23/23
Date modified: 10/24/23
Description: Determines if any lower scorecard selctions can be used that would net any points
Input: canPlay[][], frequency[], int player, dice_arr[]
Output: none
Precondition: Player is done rolling dice
Postcondition: Player will make their selection after given a suggestion*/
void suggest_lower(int canPlay[][14], int frequency[], int player, int dice_arr[]) {
	printf("Here are all of the face values you could play that could net you points: \n");
	for (int i = 1; i < 7; i++) {
		if ((canPlay[player][i] == 1) && (frequency[i] > 0)) {
			switch (i){
			case 1:printf(" Ones - %d\n", (frequency[1] * 1));
				break;
			case 2:printf(" Twos - %d\n", (frequency[2] * 2));
				break;
			case 3:printf(" Threes - %d\n", (frequency[3] * 3));
				break;
			case 4:printf(" Fours - %d\n", (frequency[4] * 4));
				break;
			case 5:printf(" Fives - %d\n", (frequency[5] * 5));
				break;
			case 6:printf(" Sixes - %d\n", (frequency[6] * 6));
				break;
				}
		}
	}
}